using EmpMgmt;
using ModelLayer;
namespace EmpMgmtTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_AddEmployee()
        {
            ServiceLayer.svcemployee empservice = new ServiceLayer.svcemployee();

            Employee employee = new Employee();
            employee.id = 0;
            employee.name  = "Test";
            employee.email = "Test@gmail.com";
            employee.gender = "male";
            employee.status = "active";

            var tresult = empservice.Addemployee(employee);
            Assert.AreEqual(tresult, "Employee Added Successfully");

        }

        [TestMethod]
        public void Test_DeleteEmployee()
        {
            ServiceLayer.svcemployee empservice = new ServiceLayer.svcemployee();
            String empid = "1234";
            var tresult = empservice.DeleteEmployee(empid);
            Assert.AreEqual(tresult, "Employee Deleted Successfully");
        }

        [TestMethod]
        public void Test_GetEmployee()
        {
            ServiceLayer.svcemployee empservice = new ServiceLayer.svcemployee();
            String empid = "1234";
            var output = empservice.GetEmployee(empid);
            String tresult = "";
            if (output.Contains("Error"))
                tresult = "Error";
            else
                tresult = "success";

            Assert.AreEqual(tresult, "success");
        }
    }
}