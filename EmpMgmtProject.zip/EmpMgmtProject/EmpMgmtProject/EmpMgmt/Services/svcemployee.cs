﻿using System.Net;
using System.Net.Http.Headers;
using System.IO;
using ModelLayer;

namespace ServiceLayer
{
    public class svcemployee
    {
        //Variable Declaration
        String url = "https://gorest.co.in/public/v2/users";
        String apitoken = "Bearer 0bf7fb56e6a27cbcadc402fc2fce8e3aa9ac2b40d4190698eb4e8df9284e2023";
        public String GetAllEmployee()
        {
            var result = "";
            try
            {
                var httpRequest = (HttpWebRequest)WebRequest.Create(url);
                httpRequest.Headers["Authorization"] = apitoken;
                var httpResponse = (HttpWebResponse)httpRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    result = streamReader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                result = "Error - " + ex.Message.ToString();
            }
            return result;

        }

        public String GetEmployee(String empid)
        {
            var result = "";
            try
            {
                var httpRequest = (HttpWebRequest)WebRequest.Create(url + "/" + empid);
                httpRequest.Headers["Authorization"] = apitoken;
                var httpResponse = (HttpWebResponse)httpRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    result = streamReader.ReadToEnd();
                }
            }
            catch (Exception ex) 
            {
                result = "Error - " + ex.Message.ToString();
            }
            return result;

        }

        public String Addemployee(Employee emp)
        {
            var result = "";

            try
            {
                var httpRequest = (HttpWebRequest)WebRequest.Create(url);
                httpRequest.Method = "POST";

                httpRequest.Headers["Authorization"] = apitoken;
                httpRequest.ContentType = "application/json";
                var data = "{\"id\":" + emp.id + ",\"name\":\"" + emp.name + "\",\"email\":\"" + emp.email + "\",\"gender\":\"" + emp.gender + "\",\"status\":\"" + emp.status + "\"}";
                using (var streamWriter = new StreamWriter(httpRequest.GetRequestStream()))
                {
                    streamWriter.Write(data);
                }
                var httpResponse = (HttpWebResponse)httpRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    result = "Employee Added Successfully";
                }
            } catch (Exception ex)
            {
                result = "Error - " + ex.Message.ToString();
            }
            return result;
        }

       public String DeleteEmployee(String empid)
        {
            var result = "";
            try
            {
                var httpRequest = (HttpWebRequest)WebRequest.Create(url + "/" + empid);
                httpRequest.Method = "DELETE";
                httpRequest.Headers["Authorization"] = apitoken;
                var httpResponse = (HttpWebResponse)httpRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    result = "Employee Deleted Successfully";
                }
            }
            catch(Exception ex)
            {
                result = "Error - " + ex.Message.ToString();
            }
            return result;

                
        }


    }
}
