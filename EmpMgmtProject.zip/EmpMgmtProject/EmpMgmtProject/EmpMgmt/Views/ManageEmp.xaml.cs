﻿using ServiceLayer;
using System.Data;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ModelLayer;

namespace EmpMgmt
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ServiceLayer.svcemployee empsvc = new ServiceLayer.svcemployee();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                var jsonData = empsvc.GetAllEmployee();
                Employee[] emplist = JsonSerializer.Deserialize<Employee[]>(jsonData);
                List<Employee> list = new List<Employee>();
                foreach (Employee emp in emplist)
                {
                    list.Add(emp);
                }
                datagrid1.ItemsSource = list;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message.ToString());
            }

        }


        private void Addbtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtempid.Text.Trim() == "")
                {
                    MessageBox.Show("Enter EmpId");
                }
                else if (txtempname.Text.Trim() == "")
                {
                    MessageBox.Show("Enter Emp Name");
                }
                else if (txtempmail.Text.Trim() == "")
                {
                    MessageBox.Show("Enter Emp Email");
                }
                else if (cbogender.Text.Trim() == "")
                {
                    MessageBox.Show("Enter Emp Gender");
                }
                else if (cbostatus.Text.Trim() == "")
                {
                    MessageBox.Show("Enter Emp Status");
                }
                else
                {
                    Employee emp = new Employee();
                    emp.id = Convert.ToInt32(txtempid.Text.Trim());
                    emp.name = txtempname.Text.Trim();
                    emp.email = txtempmail.Text.Trim();
                    emp.gender = cbogender.Text.Trim();
                    emp.status = cbostatus.Text.Trim();
                    var resp = empsvc.Addemployee(emp);
                    MessageBox.Show(resp);
                    txtempname.Text = "";
                    txtempmail.Text = "";
                    cbogender.Text = "";
                    cbostatus.Text = "";

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message.ToString());
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                var jsonData = empsvc.GetAllEmployee();
                Employee[] emplist = JsonSerializer.Deserialize<Employee[]>(jsonData);
                List<Employee> list = new List<Employee>();
                Utils utils = new Utils();
                utils.exportdata("C:\\Downloads\\empinfo.csv", emplist);
                MessageBox.Show("Exported Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message.ToString());
            }
        }

        private void btn_getemployee(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtempid.Text.Trim() == "")
                {
                    MessageBox.Show("Enter EmpId to Get Employee Details");
                }
                else
                {
                    var jsonData = empsvc.GetEmployee(txtempid.Text);
                    if (jsonData != "")
                    {
                        Employee emp = JsonSerializer.Deserialize<Employee>(jsonData);
                        if (emp != null)
                        {
                            txtempid.Text = emp.id.ToString();
                            txtempname.Text = emp.name;
                            txtempmail.Text = emp.email;
                            cbogender.Text = emp.gender;
                            cbostatus.Text = emp.status;
                        }
                        else
                        {
                            MessageBox.Show("EmpId Not Found");
                        }
                    }
                    else
                    {
                        MessageBox.Show("EmpId Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message.ToString());
            }
        }

        private void btndelete_click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtempid.Text.Trim() == "")
                {
                    MessageBox.Show("Enter EmpId to Delete Employee Record");
                }
                else
                {
                    var result = empsvc.DeleteEmployee(txtempid.Text);
                    if (!result.Contains("Error"))
                        MessageBox.Show("Deleted Successfully");
                    else
                        MessageBox.Show("Invalid EmployeeId");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message.ToString());
            }
        }

        private void btnclear_click(object sender, RoutedEventArgs e)
        {
            txtempid.Text = "";
            txtempname.Text = "";
            txtempmail.Text = "";
            cbogender.Text = "";
            cbostatus.Text = "";
        }
    }
}