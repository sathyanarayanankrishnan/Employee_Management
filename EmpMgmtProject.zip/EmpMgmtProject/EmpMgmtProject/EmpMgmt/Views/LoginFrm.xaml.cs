﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmpMgmt.Views
{
    /// <summary>
    /// Interaction logic for LoginFrm.xaml
    /// </summary>
    public partial class LoginFrm : Window
    {
        public LoginFrm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click_1(object sender, RoutedEventArgs e)
        {
            String userid = txtUserId.Text.Trim().ToString();
            String pwd = txtPassword.Password.Trim().ToString();
            if (userid == "")
            {
                MessageBox.Show("Please Enter UserId");
                txtUserId.Focus();
            }
            else if (pwd == "")
            {
                MessageBox.Show("Please Enter Password");
                txtPassword.Focus();
            }
            else if(userid.ToLower() == "admin" &&  pwd.ToLower() == "admin") 
            {
                MainWindow mwin = new MainWindow();
                mwin.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid Login");
            }
        }

        private void btnClose_Click_1(object sender, RoutedEventArgs e)
        {
            txtUserId.Text = "";
            txtPassword.Password = "";
        }
    }
}
